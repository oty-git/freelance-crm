import React from "react";
import {Trans} from 'react-i18next';
const urgency = [
    {id: 1, label: <Trans>Urgent</Trans>, value: 'urgent'},
    {id: 2, label: <Trans>Delay</Trans>, value: 'delay'},
];
export default urgency;
