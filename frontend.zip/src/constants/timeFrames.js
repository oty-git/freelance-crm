const timeFrames = [
    {id: 1, label: '-1h', value: '-1h'},
    {id: 2, label: '-2h', value: '-2h'},
    {id: 3, label: '-3h', value: '-3h'},
    {id: 4, label: '-4h', value: '-4h'},
    {id: 5, label: '-5h', value: '-5h'},
    {id: 6, label: '+1h', value: '+1h'},
    {id: 7, label: '+2h', value: '+2h'},
    {id: 8, label: '+3h', value: '+3h'},
    {id: 9, label: '+4h', value: '+4h'},
    {id: 10, label: '+5h', value: '+5h'},
];
export default timeFrames;
