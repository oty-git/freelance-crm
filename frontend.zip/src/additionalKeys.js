import {Trans} from 'react-i18next';
import React from "react";
export default [
    <Trans>skills</Trans>,
    <Trans>expertises</Trans>,
    <Trans>employee</Trans>,
    <Trans>freelancer</Trans>,
    <Trans>employees</Trans>,
    <Trans>freelancers</Trans>,
    <Trans>Employee</Trans>,
    <Trans>Freelancer</Trans>,
    <Trans>Employees</Trans>,
    <Trans>Freelancers</Trans>,
    <Trans>Search skills or press Enter to create new</Trans>,
    <Trans>Search expertises or press Enter to create new</Trans>,
    <Trans>Skills</Trans>,
    <Trans>Expertises</Trans>,
    <Trans>Add skills</Trans>,
    <Trans>Add expertises</Trans>,
];
