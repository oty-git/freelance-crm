import React from "react";
import SettingsPageWrap from "./settings/SettingsPageWrap";


const Settings = () => {
    return <SettingsPageWrap />
};

export default Settings;
